:orphan:

==========
pip-freeze
==========

Description
***********

.. pip-command-description:: freeze

Usage
*****

.. pip-command-usage:: freeze

Options
*******

.. pip-command-options:: freeze
