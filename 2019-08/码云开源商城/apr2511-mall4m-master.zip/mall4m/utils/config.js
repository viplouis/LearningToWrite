//可改动页面

var domain = "https://mini-api.gz-yami.com"; //统一接口域名，正式环境
//  var domain = "http://192.168.0.173:8086"; //统一接口域名，测试环境
//var domain = "http://192.168.0.153:8286"; //测试环境

// var picDomain = '';//图片域名

exports.domain = domain;

// exports.picDomain = picDomain;